# Dynamic Causal Hypergraph (DCH) — Pipeline package
# License: MIT

"""
Pipeline package exposing orchestration utilities for DCH.

Primary exports
- Configs: DHGConfig, TraversalConfig, PlasticityConfig, PipelineConfig
- DCHPipeline: orchestrator that ties together hypergraph storage, DHG constructor,
  traversal, and plasticity engines, with optional encoder for data preparation.

See:
- docs/EVALUATION_PROTOCOL.md
- dch_pipeline/pipeline.py
"""

from __future__ import annotations

from .pipeline import (
    DHGConfig,
    TraversalConfig,
    PlasticityConfig,
    PipelineConfig,
    DCHPipeline,
    ManifoldConfig,
)

__all__ = [
    "DHGConfig",
    "TraversalConfig",
    "PlasticityConfig",
    "PipelineConfig",
    "DCHPipeline",
    "ManifoldConfig",
]

# Re-export version string from dch_core for convenience
try:
    from dch_core import __version__ as __version__  # re-export
except Exception:
    __version__ = "0.0.0"